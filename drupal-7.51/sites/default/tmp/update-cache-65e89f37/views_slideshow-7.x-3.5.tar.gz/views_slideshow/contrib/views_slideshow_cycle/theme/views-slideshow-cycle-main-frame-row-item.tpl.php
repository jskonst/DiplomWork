<?php

/**
 * @file
 * Views Slideshow cycle: Main frame row item.
 *
 * - $classes: Classes.
 * - $item: Row item.
 *
 * @ingroup views_templates
 */
?>
<div class="<?php print $classes; ?>">
  <?php print $item; ?>
</div>
